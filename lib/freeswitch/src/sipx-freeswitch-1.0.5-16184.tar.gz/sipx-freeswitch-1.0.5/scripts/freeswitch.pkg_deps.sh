#!/bin/sh

wget -c http://svn.freeswitch.org/downloads/libs/celt-0.6.1.tar.gz
wget -c http://svn.freeswitch.org/downloads/libs/flite-1.3.99-latest.tar.gz
wget -c http://svn.freeswitch.org/downloads/libs/lame-3.97.tar.gz
wget -c http://svn.freeswitch.org/downloads/libs/libshout-2.2.2.tar.gz
wget -c http://svn.freeswitch.org/downloads/libs/mpg123.tar.gz
wget -c http://svn.freeswitch.org/downloads/libs/openldap-2.4.11.tar.gz
wget -c http://svn.freeswitch.org/downloads/libs/pocketsphinx-0.5.99-latest.tar.gz
wget -c http://svn.freeswitch.org/downloads/libs/soundtouch-1.3.1.tar.gz
wget -c http://svn.freeswitch.org/downloads/libs/sphinxbase-0.4.99-latest.tar.gz
wget -c http://files.freeswitch.org/freeswitch-sounds-music-8000-1.0.8.tar.gz
wget -c http://files.freeswitch.org/freeswitch-sounds-music-16000-1.0.8.tar.gz
wget -c http://files.freeswitch.org/freeswitch-sounds-music-32000-1.0.8.tar.gz
wget -c http://files.freeswitch.org/freeswitch-sounds-music-48000-1.0.8.tar.gz
wget -c http://files.freeswitch.org/freeswitch-sounds-en-us-callie-8000-1.0.11.tar.gz
wget -c http://files.freeswitch.org/freeswitch-sounds-en-us-callie-16000-1.0.11.tar.gz
wget -c http://files.freeswitch.org/freeswitch-sounds-en-us-callie-32000-1.0.11.tar.gz
wget -c http://files.freeswitch.org/freeswitch-sounds-en-us-callie-48000-1.0.11.tar.gz
wget -c http://svn.freeswitch.org/downloads/libs/communicator_semi_6000_20080321.tar.gz


